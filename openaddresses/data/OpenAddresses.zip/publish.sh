#!/bin/bash
export SVN_EDITOR=cat
zip OpenAddresses.zip *
cp *.zip /Users/jko/Dropbox/public/OA
mv *.zip /Projects/OA.org/openaddresses/openaddresses/data
cd /Projects/OA.org/openaddresses/openaddresses/data
svn commit
cd -

